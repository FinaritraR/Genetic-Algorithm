import java.util.Arrays;
import java.util.Random;

/** 
 * A <code>Population</code> is a collection of individuals (each one
 * representing a candidate solution for the n-queens problem).  To
 * facilitate the implementation of the various methods, <b>the
 * individuals will always be kept in increasing value of fitness</b>.
 */

public class Population {
    
    private static final Random random = new Random();
    
    private static final int TOURNAMENT_SIZE = 5;

    private static final double MUTATION_RATE = 0.8;
    
    private Individual[] individuals;
    private int size; 
 
    /**
     * A constructor of arity 2 to initialize the <b>Population</b>.
     * 
     * @param size is the number of individuals of this population
     * @param dimension is the size of the board and also the number of queens
     */

    public Population(int size, int dimension) {
	this.size = size;
	individuals = new Individual[size];
	for (int i=0;i<size; i++) {
	    individuals[i] = new Individual(dimension); 
	}
	Arrays.sort(individuals); // done once, when a population is created
    }
    
    /**
     * The method <code>evolve</code> selects parent individuals. An offspring
     * is then created from the two parents, using the method
     * <code>crossover</code>. With probability <code>MUTATION_RATE</code>, the
     * offspring is <code>mutated</code>. Use 0.8 as the default
     * <code>MUTATION_RATE</code> The resulting child is inserted into the
     * population. As a result, the least fitted individual will be eliminated
     * from the population. Remember that the <code>population</code> is kept in
     * increasing order of fitness. For the selection of the parents, you can
     * experiment with different scenarios. A possible scenario is to randomly
     * select two parents. Another possible one would be to select the most fit,
     * and a randomly selected one. Or else, select the two most fitted
     * individuals.
     */

    public void evolve() {
	
	// precondition: TOURNAMENT_SIZE >=3

	Individual[] selection;
	Individual adam, eve;
	selection = new Individual[TOURNAMENT_SIZE];
	
	for (int i=0;i<TOURNAMENT_SIZE; i++) {
	    selection[i] = individuals[random.nextInt(size)];
	}
	
	Arrays.sort(selection); // selection is a small array, sorting it has a small cost
	
	adam = selection[0].recombine(selection[1]);
	if (random.nextDouble()<MUTATION_RATE) {
	    eve = adam.mutate();
	    insert(eve);
	} else {
	    insert(adam);
	}
	
	adam = selection[1].recombine(selection[2]);
	
	if (random.nextDouble()<MUTATION_RATE) {
	    eve = adam.mutate();
	    insert(eve);
	} else {
	    insert(adam);
	}
	
    }
    
    /**
     * A helper method that inserts this individual into the population such
     * that the population is kept in increasing order of fitness. During
     * the execution of the program, it will be more efficient to use
     * the method insert, rather than calling Arrays.sort.
     * 
     * @param individual to be inserted into the population
     */
    
    private void insert(Individual individual) {
	int position = 0;
	while (position<size && individual.getFitness() > individuals[position].getFitness()) {
	    position++;
	}
	if (position<size) {
	    for (int i=size-1; i>position; i--) {
		individuals[i] = individuals[i-1];
	    }
	    individuals[position] = individual;
	}
    }
    
    /**
     * The instance method <code>public Individual getFittest()</code> returns the
     * "best" individual of the population, i.e. the one that has the smallest
     * fitness value.
     * 
     * @return returns the currently best solution
     */
     
    public Individual getFittest() {
	return individuals[0];
    }
    
    /**
     * Returns a <code>String</code> representation of this <code>Population</code>.
     * 
     * @return the String representation of this Population
     */

    public String toString() {
	return this.getClass().getName() + " [individuals=" + Arrays.toString(individuals) + "]";
    }

}
