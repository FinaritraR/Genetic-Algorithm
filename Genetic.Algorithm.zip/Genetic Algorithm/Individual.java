import java.util.Random;

/**
 * An <code>Individual</code> (a chromosome) is a candidate solution for a given
 * problem. Its representation depends on the specific problem to be solved. Two
 * individuals can be combined (see method crossover) to produce a new
 * offspring. As with natural chromosomes, these artificial ones suffer
 * mutations. Each chromosome has a fitness value that indicates the quality of
 * this solution.
 * 
 * A <code>Population</code> is a collection of chromosomes. At each iteration
 * (generation), the genetic algorithm selects chromosomes for reproduction. The
 * offsprings are inserted into the population, and the least fitted individuals
 * are eliminated. Thus, the size of the population is fixed.
 * 
 * For this assignment, an <code>Individual</code> represents a solution to the
 * <code>n</code>-Queens problem. As introduced in the assignment description, a
 * candidate solution is represented by a permutation of size <code>n</code>,
 * such that attribute <code>i</code> represents the row for the queen found at
 * column <code>i</code>.
 * 
 * Not all permutations are valid solutions to <code>n</code>-Queens problem. A
 * permutation is a valid solution if no two queens can attack each other. Two
 * queens are attacking each other if they are on the same row or column, which
 * is impossible given this representation, but also if they are found on the
 * same minor or major diagonal.
 *
 * Herein, we define the fitness value of an individual as the number of pairs
 * of queens attacking each other.
 *
 * You must complete the implementation of the class <code>Individual</code>
 * following all the directives.
 *
 * @author Marcel Turcotte (turcotte@eecs.uottawa.ca)
 */


public class Individual implements Comparable<Individual> {

    private static final Random random = new Random();

    private final int size; // 5
    private int[] attributes;
    private int fitness;

    /**
     * Creates an <code>Individual</code> having <code>size</code> attributes.
     * This constructor is used by the class <code>Population</code>.
     * 
     * @param size the number of attributes of this <code>Individual</code>
     */
    
    public Individual(int size) {

	// precondition: size >= 0
	
	this(Util.getPermutation(size));
    }

    /**
     * Creates an <code>Individual</code> using the provided permutation. The method
     * must copy the values of the permutation into a new array. This constructor
     * is primarily used for testing.
     * 
     * @param permutation used to initialize the attributes of this <code>Individual</code>
     */

    public Individual(int[] permutation) { // 10

	// precondition: genes is valid permutation
	
	this.size = permutation.length;
	this.attributes = new int[size];
	
	System.arraycopy(permutation, 0, this.attributes, 0, size);
	
	evaluate2();
    }

    /**
     * Returns the offspring resulting from the crossover of <code>this</code>
     * <code>Individual</code> and <code>other</code>. The result must be a valid
     * permutation!
     * 
     * In particular, the naive solution consisting of taking the first
     * <code>position-1</code> attributes of this <code>Individual</code> and
     * the last <code>size-position</code> attributes of <code>other</code> would
     * not generate a valid permutation in most cases.
     *  
     * Instead, we are proposing that the first <code>position-1</code> attributes 
     * of this <code>Individual</code> are copied to the offspring, then the
     * missing values will be selected from <code>other</code>, whilst preserving
     * their order of appearance in <code>other</code>.
     * 
     * This method is primarily used for testing.
     * 
     * @param other a reference to an <code>Individual</code>
     * @param position the location of the crossover
     * @return the offspring resulting from the crossover of <code>this</code> and <code>other</code>
     */
    
    public Individual crossover(Individual other, int position) { // 15 marks
	
	// precondition: other is not null and position is a valid index
	
	int[] individual = new int[size];
	for (int i = 0; i < position; i++) {
	    individual[i] = this.attributes[i];
	}
	int current = position;
	for (int j = 0; j < size; j++) {
	    boolean found = false;
	    int candidate = other.attributes[j];
	    for (int k = 0; k < position && (!found); k++) {
		if (individual[k] == candidate) {
		    found = true;
		}
	    }
	    if (!found) {
		individual[current] = candidate;
		current++;
	    }
	}
	return new Individual(individual);
    }

    /**
     * Returns the offspring resulting from the crossover of <code>this</code>
     * <code>Individual</code> and <code>other</code>. The method randomly selects the
     * position of the crossover. The result must be a valid permutation!
     * 
     * In particular, the naive solution consisting of taking the first
     * <code>position-1</code> attributes of this <code>Individual</code> and the last
     * <code>size-position</code> attributes of <code>other</code> would not generate a
     * valid permutation in most cases.
     * 
     * Instead, we are proposing that the first <code>position-1</code> attributes
     * of this <code>Individual</code> are copied to the offspring, then the missing
     * values will be selected from <code>other</code>, whilst preserving their
     * order of appearance in <code>other</code>.
     * 
     * This method is used by <code>Population</code>.
     * 
     * @param other a reference to an <code>Individual</code>
     * @return the offspring resulting from the crossover of <code>this</code> and <code>other</code>
     */
    
    public Individual recombine(Individual other) { // 3 marks
	
	// precondition: other is not null
	
	return crossover(other, 1 + random.nextInt(size - 2));
    }
    
    /**
     * Returns the offspring resulting from applying a mutation
     * to this <code>Individual</code>. In order to make sure that 
     * the result is valid permutation, the method exchanges
     * the value of two attributes, those found at positions
     * <code>i</code> and <code>j</code>.
     * 
     * This method is primarily used for testing.
     * 
     * @param i the first attribute 
     * @param j the second attribute
     * @return the offspring resulting from exchanging attributes <code>i</code> and <code>j</code>
     */

    public Individual mutate(int i, int j) { // 10
	
	// precondition: i != j, i and j are valid indexes
	
	Individual copy;
	copy = new Individual(attributes);
	
	int attribute = copy.attributes[i];
	copy.attributes[i] = copy.attributes[j];
	copy.attributes[j] = attribute;
	
	copy.evaluate2();
	
	return copy;
    }

    /**
     * Returns the offspring resulting from applying a mutation
     * to this <code>Individual</code>. In order to make sure that 
     * the result is valid permutation, the method exchanges
     * the value of two randomly selected attributes.
     * 
     * This method is called by <code>Population</code>.
     * 
     * @return the offspring resulting from exchanging two randomly selected attributes
     */

    public Individual mutate() {
	int i, j;
	do {
	    i = random.nextInt(size);
	    j = random.nextInt(size);
	} while (i == j);
	return mutate(i, j);
    }
    
    /**
     * Returns the fitness value of <code>this Individual</code>, which
     * is defined as the number of pairs of queens attacking each
     * other.
     * 
     * @return the fitness value of <code>this Individual</code>. 
     */

    public int getFitness() { // 5 marks
	return fitness;
    }

    /**
     * A helper method that calculates and stores the fitness value,
     * defined as the number of pairs of queens attacking each
     * other. With this method k-queens on the same diagonal adds k*(k-1)/2 
     * to the fitness value. Considers n*n pairs of queens.
     */
    
    private void evaluate() { // 10 marks
	
	int count = 0;

	for (int r1 = 0; r1 < size; r1++) {
	    int c1 = this.attributes[r1];
	    for (int r2 = r1 + 1; r2 < size; r2++) {
		int c2 = this.attributes[r2];
		if (r1 - c1 == r2 - c2) { // same minor diagonal?
		    count++;
		} else if (c1 + r1 == c2 + r2) { // same major diagonal?
		    count++;
		}
	    }
	}

	fitness = count;
    }
 
    /**
     * A helper method that calculates and stores the fitness value, defined as
     * the number of pairs of queens attacking each other. With this method
     * k-queens on the same diagonal adds (k-1) to the fitness value. This
     * fitness value corresponds to the actual chess rules, but also requires
     * fewer computations: 2*n-1 computations for the major diagonals, same
     * computations for the minor diagonals. However, it requires more
     * temporary space!
     */
    private void evaluate2() { // 10 marks

        int major[], minor[];
        major =  new int[2*size-1];
        minor =  new int[2*size-1];

        for (int row = 0; row < size; row++) {
            int column = this.attributes[row];
            minor[(size - 1) + (row - column)]++;
            major[column + row]++;
        }

        int count = 0;
        
        for (int i = 0; i < major.length; i++) {
            if (major[i] > 1) {
                count += major[i] - 1;
            }
            if (minor[i] > 1) {
                count += minor[i] - 1;
            }
        }

        fitness = count;
    }
   
    /**
     * Returns a negative integer, zero, or a positive integer as the fitness of this <code>Individual</code> is
     * less than, equal to, or greater than the fitness of the specified <code>Individual</code>. 
     * 
     * @param other <code>Individual</code> to be compared
     * @return a negative integer, zero, or a positive integer as the fitness of this <code>Individual</code> is less than, equal to, or greater than the fitness of the specified <code>Individual</code>.
     */
    
    @Override
    public int compareTo(Individual other) { // 3 marks
	return this.getFitness() - other.getFitness();
    }

    /**
     * Returns a string representation of this <code>Individual</code>.
     * 
     * @return a string representation of this <code>Individual</code>
     */
    
    @Override
    public String toString() { // 10 marks
	StringBuffer out;
	out = new StringBuffer(getClass().getName());
	out.append(": {fitness=");
	out.append(this.getFitness());
	out.append(", attributes=[");
	for (int i = 0; i < size; i++) {
	    if (i > 0) {
		out.append(",");
	    }
	    out.append(attributes[i]);
	}
	out.append("]}");
	return out.toString();
    }
    
    /**
     * Runs a series of tests.
     * 
     * @param args command line parameters of the program
     */

    public static void main(String[] args) {
        
	Individual genotype1, genotype2, genotype3;
	
	//TODO: Create more tests, report errors whenever a problem is found...

	genotype1 = new Individual(new int[] { 0, 1, 2, 3, 4, 5, 6, 7 });
	genotype2 = new Individual(new int[] { 7, 6, 5, 4, 3, 2, 1, 0 });
	genotype3 = genotype1.crossover(genotype2, 4);
	System.out.println(genotype1);
	System.out.println(genotype2);
	System.out.println(genotype3);
	genotype3.mutate(1,6);
	System.out.println(genotype3);
	System.out.println();

	genotype1 = new Individual(8);
	genotype2 = new Individual(8);
	genotype3 = genotype1.recombine(genotype2);
	System.out.println(genotype1);
	System.out.println(genotype2);
	System.out.println(genotype3);
	genotype3.mutate();
	System.out.println(genotype3);

    }
}
